import { BackService } from './../../services/back.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm, Validators } from '@angular/forms';


@Component({
  selector: 'app-take-survey',
  templateUrl: './take-survey.component.html',
  styleUrls: ['./take-survey.component.scss']
})
export class TakeSurveyComponent implements OnInit {
  isSubmitted = false;
  constructor(public fb: FormBuilder, private backService: BackService) { }
  survey:any;

  ngOnInit(): void {
    this.survey=this.backService.getSuvry(this.backService.currentSuvey)
    console.log(this.survey)
  }




  registrationForm = this.fb.group({
    gender: [''],

  });

  get myForm() {
    return this.registrationForm.get('gender');
  }



  onSubmit() {
    this.isSubmitted = true;
    if (!this.registrationForm.valid) {
      return false;
    } else {
      return alert(JSON.stringify(this.registrationForm.value));
    }
  }
  }






function value(value: any, any: any) {
  throw new Error('Function not implemented.');
}


