import { Router } from '@angular/router';
import { BackService } from './../../../services/back.service';
import { Component, OnInit } from '@angular/core';
import { RespondedService } from 'src/app/services/responded.service';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-respond-home',
  templateUrl: './respond-home.component.html',
  styleUrls: ['./respond-home.component.scss']
})
export class RespondHomeComponent implements OnInit {
  mydata: any;
  submitted = false;
  title = '';
  survey:any;

  constructor(private responded: RespondedService, private backService: BackService,private router: Router ) {}
  ngOnInit(): void {
    this.survey = this.backService.getAllSurvey()
  }

  takeSurvey(id:any){
      this.backService.takingSurvey(id);
      this.router.navigateByUrl("/take-survey")
  }

  getstatus(){
    return this.responded.surveyactive().subscribe({
      next:data =>{
        this.mydata = data
        console.log(data)
      }
    })
  }
}
