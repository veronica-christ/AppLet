export interface survey {
    title :string;
    description :string;
    status :string;
}
